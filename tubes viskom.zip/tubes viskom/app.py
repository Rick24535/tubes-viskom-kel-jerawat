import os
import numpy as np
from flask import Flask, request, render_template, send_file, redirect, url_for, flash
from keras.models import load_model
from keras.preprocessing import image
from werkzeug.utils import secure_filename
from PIL import Image, ImageDraw
from datetime import datetime, timedelta

# Setup Flask app
app = Flask(__name__)
app.secret_key = 'supersecretkey'  # Required for flashing messages

# Paths for file upload and results
UPLOAD_FOLDER = 'uploads'
RESULT_FOLDER = 'results'
ALLOWED_EXTENSIONS = {'png', 'jpg', 'jpeg'}
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER
app.config['RESULT_FOLDER'] = RESULT_FOLDER

# Load model once when the app starts
model = load_model('best_model.h5')  # Ganti dengan path model Anda

# Define acne locations mapping
acne_locations = {
    "Pustula": "dahi, hidung, dagu, pipi",
    "Acne Fulminans": "dahi, hidung, dagu, pipi, rahang",
    "Acne Nodules": "Pipi, dagu, rahang",
    "Fungal Acne": "Dahi dan sisi wajah",
    "Papula": "dahi, hidung, dagu, pipi, rahang",
    "Rosacea": "hidung, pipi, dahi, dagu"
}

# Validate allowed file extensions
def allowed_file(filename):
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

# Function to determine severity based on confidence
def determine_severity(confidence):
    if confidence < 0.65:
        return "Ringan"
    elif confidence < 0.8:
        return "Sedang"
    else:
        return "Parah"

# Clean up old files
def cleanup_files(folder, age_limit=1):
    now = datetime.now()
    for filename in os.listdir(folder):
        file_path = os.path.join(folder, filename)
        if os.path.isfile(file_path):
            file_age = datetime.fromtimestamp(os.path.getmtime(file_path))
            if now - file_age > timedelta(hours=age_limit):
                os.remove(file_path)

# Route to home page
@app.route('/')
def home():
    return render_template('index.html')

# Route to handle prediction
@app.route('/predict', methods=['POST'])
def predict():
    if 'file' not in request.files:
        flash("Tidak ada file yang diunggah!")
        return redirect(url_for('home'))
    
    file = request.files['file']
    if file.filename == '':
        flash("File tidak dipilih!")
        return redirect(url_for('home'))
    
    if not allowed_file(file.filename):
        flash("Format file tidak didukung! Harap unggah file dengan format PNG, JPG, atau JPEG.")
        return redirect(url_for('home'))
    
    try:
        # Save the uploaded file
        filename = secure_filename(file.filename)
        filepath = os.path.join(app.config['UPLOAD_FOLDER'], filename)
        file.save(filepath)

        # Preprocess the image
        img = image.load_img(filepath, target_size=(224, 224))
        img_array = image.img_to_array(img)
        img_array = np.expand_dims(img_array, axis=0)
        img_array /= 255.0

        # Make prediction
        preds = model.predict(img_array)
        confidence = np.max(preds)
        predicted_class = np.argmax(preds)

        # Map class index to label
        class_labels = {0: 'Pustula', 1: 'Acne Fulminans', 2: 'Acne Nodules', 3: 'Fungal Acne', 4: 'Papula', 5: 'Rosacea'}
        predicted_label = class_labels[predicted_class]

        # Determine severity
        severity = determine_severity(confidence)
        location = acne_locations.get(predicted_label, "Lokasi tidak ditemukan.")

        # Annotate image
        img = Image.open(filepath)
        draw = ImageDraw.Draw(img)
        draw.rectangle([10, 10, 214, 214], outline="red", width=3)  # Example bounding box
        result_path = os.path.join(app.config['RESULT_FOLDER'], filename)
        img.save(result_path)

        # Clean up old files
        cleanup_files(app.config['UPLOAD_FOLDER'])
        cleanup_files(app.config['RESULT_FOLDER'])

        return render_template(
            'result.html', 
            predicted_label=predicted_label, 
            severity=severity, 
            location=location, 
            result_image=filename
        )
    except Exception as e:
        flash(f"Terjadi kesalahan: {str(e)}")
        return redirect(url_for('home'))

# Route to serve the result image
@app.route('/results/<filename>')
def results(filename):
    return send_file(os.path.join(app.config['RESULT_FOLDER'], filename))

if __name__ == '__main__':
    os.makedirs(UPLOAD_FOLDER, exist_ok=True)
    os.makedirs(RESULT_FOLDER, exist_ok=True)
    app.run(debug=True)
